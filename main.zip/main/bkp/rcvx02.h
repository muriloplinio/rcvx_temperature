#ifndef RCVX02_H
#define RCVX02_H

#ifdef __cplusplus
extern "C" {
#endif

/**********************
 *      INCLUDES
 **********************/

/*#include "lvgl.h"*/

/**********************
 *       WIDGETS
 **********************/

/**********************
 * GLOBAL PROTOTYPES
 **********************/

void rcvx02_create(lv_obj_t *parent);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*RCVX02_H*/